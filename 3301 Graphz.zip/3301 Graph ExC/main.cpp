#include <iostream>
#include <vector>
#include <iomanip>
#include <string>
#include <list>
#include <set>

#include <fstream>
#include <sstream>

using namespace std;

class graph{
    int v;
    list<pair<int,int>> *li;
public:
    graph(int v){
        this->v = v;
        li = new list<pair<int,int>>[v];
    }   

    void addEdge(int x, int y, int z){
        li[x].push_back(make_pair(y,z));
        li[y].push_back(make_pair(x,z));
    } 

    void printList(){
        for(int i=0; i<v; i++){
            cout << "Vertex " << i << ": \n";

            for(auto it = li[i].begin(); it != li[i].end(); it++){
                cout << i << " -> " << it->first << ", Weights: " << it->second << endl;
            }

            cout << endl; 
        }

    }

    void Dijkstra(int start, int end){

        set<pair<int, int>> set_dist;

        vector<int> dist(v, 999); //all distances infinite

        set_dist.insert(make_pair(0, start));
        dist[start] = 0;

        while(!set_dist.empty()){

            pair<int, int> temp = *(set_dist.begin());
            set_dist.erase(set_dist.begin());


            int u = temp.second;

            list<pair<int, int>>::iterator i;

            for (i = li[u].begin(); i != li[u].end(); ++i){
                //dereference
                int v = (*i).first;
                int weight = (*i).second;
 
            //find alternate shorter path.
                if (dist[v] > dist[u] + weight) {
                    if (dist[v] != 999)
                        set_dist.erase(set_dist.find(make_pair(dist[v], v)));
    
                    // Update distance
                    dist[v] = dist[u] + weight;
                    set_dist.insert(make_pair(dist[v], v));
                }
            }
        }
    //print shortest dist
    for (int i = 0; i < v; ++i)
        if(i == end){
            cout << "\nFrom:" << start << " -> "<< end << " is " << dist[i] << " total weight\n\n";
            //printf("%d \t %d\n", i, dist[i]);
        }
    }

};

int main(){
    fstream graph_file;
    string line;

    graph_file.open("graph.txt");

    getline(graph_file, line);
    int n_int = stoi( line.substr(0,1) );
    int m_int = stoi( line.substr(2,1) );

    //cout << n_int << ","<< m_int <<endl;

    graph g(n_int);

    int source, destination, weight, start, g_end;
    while(getline(graph_file,line)){ //getline(graph_file,line)
        //cout << "SIZE: " << line.size() << endl;
        if(line.size() > 4){

            source = stoi( line.substr(0,1));
            destination = stoi( line.substr(2,1));
            weight = stoi( line.substr(4));

            g.addEdge(source, destination, weight);

        }else{
        
            start = stoi( line.substr(0,1) );
            g_end = stoi( line.substr(2,1) );
        }

        //cout << line << endl;
    }

    g.printList();

    cout << "Shortest Path: From " << start << " -> " << g_end << endl;


    g.Dijkstra(source, g_end);

//path between vertex 0 and vertex 3 as a sequence of vertex labels (0, 2, 3 in this example).

    return 0;
}

    //https://www.quora.com/How-does-one-read-input-until-the-end-of-file-end-of-line-in-C++
    //https://en.cppreference.com/w/cpp/container/list