Your program will read a graph from a file called graph.txt. The file is a text file where the first line
contains two numbers. The first is the number of vertices n and the second is the number of edges m.
After this line there will be m lines with three numbers. The first two numbers represent the source and
destination vertex for the undirected edge. The third number is the weight for that edge. The final line of
the file contains two numbers representing the index of two numbers. Your program should construct the
graph and run Dijkstra’s shortest path algorithm. An example file would be 

This file represents a graph with 4 vertices, 5 edges, and has edges (0,2) with weight 1, (1,2) with weight
5, (2,3) with weight 3, (1,3) with weight 2, (0,3) with weight 10. Your program should output the shortest
path between vertex 0 and vertex 3 as a sequence of vertex labels (0, 2, 3 in this example). NOTE: The
weight does NOT have to be an integer, it can also be a floating number.
To implement the graph you *may* start with this implementation (look on Blackboard) filling in the
specified functions. However, you do not have to. However you chose to implement the assignment,
your program should read the graph in graph.txt and output the solution in the format from the example
above. 



New Allocates memory on the heap
    -Needs to find an address that has the amount of bytes needed by the datatype in a row. ex int 4 bytes in a row
        -Free list
    -Returns pointer to memory address
    -New also calls constructor
-Can be overloaded, _overload operators_

int* x = new int(5); passes int 5 to the constructor as an arg,
    -Returns a pointer;
    -Need to delete the memory after; delete x
    -Lets data live beyond the scope, exists until delete is called

    class obj *u = new class();
    (*u).name; or u->name;

    Can be used for dynamic arrays

    int *array  = new int[size]; //size not const
    delete []array;
